"""Flask backend for the Hostel Gym AI + Deep Learning Tracker."""
import os
from functools import wraps
from flask import Flask, jsonify, request, send_from_directory, session

from data_gen import DAYS, EXERCISES
from models import form_feedback, load_data, load_models, predict_peak, predict_posture

HERE = os.path.dirname(os.path.abspath(__file__))
FRONTEND = os.path.join(HERE, "..", "frontend")
app = Flask(__name__, static_folder=None)
app.secret_key = os.environ.get("SECRET_KEY", "hostel-gym-demo-secret-key")
app.config["SESSION_COOKIE_HTTPONLY"] = True

USERNAME = "sravani"
PASSWORD = "sravani123"
df = load_data()
posture_model, deep_model, peak_model = load_models()


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return jsonify(error="Please login first."), 401
        return fn(*args, **kwargs)
    return wrapper


def filtered(exercises):
    if exercises:
        return df[df["exercise"].isin(exercises)]
    return df


def requested_exercises():
    raw = request.args.get("exercises")
    if raw is None:
        return None
    return [e for e in raw.split(",") if e in EXERCISES]


@app.get("/")
def index():
    return send_from_directory(FRONTEND, "index.html")


@app.get("/<path:name>")
def static_files(name):
    return send_from_directory(FRONTEND, name)


@app.post("/api/login")
def login():
    body = request.get_json(silent=True) or {}
    if body.get("username") == USERNAME and body.get("password") == PASSWORD:
        session["logged_in"] = True
        session["username"] = USERNAME
        return jsonify(ok=True, username=USERNAME)
    return jsonify(ok=False, error="Invalid username or password."), 401


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify(ok=True)


@app.get("/api/me")
def me():
    return jsonify(logged_in=bool(session.get("logged_in")), username=session.get("username"))


@app.get("/api/health")
@login_required
def health():
    return jsonify(status="ok", records=len(df), models_loaded=True, deep_learning=True)


@app.get("/api/summary")
@login_required
def summary():
    d = filtered(requested_exercises())
    if d.empty:
        return jsonify(records=0, avg_form_score=0, peak_records=0, avg_occupancy=0)
    return jsonify(records=int(len(d)), avg_form_score=round(float(d["form_score"].mean()), 1), peak_records=int(d["is_peak"].sum()), avg_occupancy=round(float(d["occupancy"].mean())))


@app.get("/api/usage-by-hour")
@login_required
def usage_by_hour():
    d = filtered(requested_exercises())
    counts = d.groupby("hour").size().reindex(range(24), fill_value=0)
    return jsonify(hours=list(range(24)), counts=[int(c) for c in counts])


@app.get("/api/posture-distribution")
@login_required
def posture_distribution():
    d = filtered(requested_exercises())
    counts = d["posture"].value_counts()
    labels = ["Good", "Needs Improvement", "Dangerous"]
    return jsonify(labels=labels, counts=[int(counts.get(l, 0)) for l in labels])


def read_posture_body():
    body = request.get_json(silent=True) or {}
    try:
        exercise = body["exercise"]
        knee, back = float(body["knee_angle"]), float(body["back_angle"])
        depth, score = float(body["depth_ratio"]), float(body["form_score"])
    except (KeyError, TypeError, ValueError):
        raise ValueError("Provide exercise, knee_angle, back_angle, depth_ratio, form_score.")
    if exercise not in EXERCISES:
        raise ValueError(f"exercise must be one of {EXERCISES}")
    return exercise, knee, back, depth, score


@app.post("/api/predict-posture")
@login_required
def api_predict_posture():
    try:
        exercise, knee, back, depth, score = read_posture_body()
    except ValueError as e:
        return jsonify(error=str(e)), 400
    label, proba = predict_posture(posture_model, exercise, knee, back, depth, score)
    return jsonify(prediction=label, probabilities=proba, feedback=form_feedback(exercise, knee, back, depth), model="Random Forest")


@app.post("/api/predict-webcam")
@login_required
def api_predict_webcam():
    """Classify posture features calculated from the live browser webcam pose landmarks."""
    try:
        exercise, knee, back, depth, score = read_posture_body()
    except ValueError as e:
        return jsonify(error=str(e)), 400
    label, proba = predict_posture(deep_model, exercise, knee, back, depth, score)
    icons = {"Good": "✅", "Needs Improvement": "⚠️", "Dangerous": "🚨"}
    return jsonify(
        prediction=label,
        probabilities=proba,
        feedback=form_feedback(exercise, knee, back, depth),
        model="Deep Neural Network",
        icon=icons.get(label, "🧠"),
    )


@app.post("/api/predict-deep-learning")
@login_required
def api_predict_deep_learning():
    try:
        exercise, knee, back, depth, score = read_posture_body()
    except ValueError as e:
        return jsonify(error=str(e)), 400
    label, proba = predict_posture(deep_model, exercise, knee, back, depth, score)
    return jsonify(prediction=label, probabilities=proba, feedback=form_feedback(exercise, knee, back, depth), model="Deep Neural Network", architecture="64 → 32 → 16 hidden layers")


@app.get("/api/deep-learning-info")
@login_required
def deep_learning_info():
    return jsonify(model="Deep Neural Network", architecture="64 → 32 → 16", activation="ReLU", input_features=7, purpose="Exercise posture classification")


@app.post("/api/predict-peak")
@login_required
def api_predict_peak():
    body = request.get_json(silent=True) or {}
    try:
        day = body["day"]
        hour = int(body["hour"])
        occupancy = int(body["occupancy"])
        sess = int(body["session_minutes"])
    except (KeyError, TypeError, ValueError):
        return jsonify(error="Provide day, hour, occupancy, session_minutes."), 400
    if day not in DAYS or not 0 <= hour <= 23:
        return jsonify(error="Invalid day or hour."), 400
    label, p = predict_peak(peak_model, day, hour, occupancy, sess)
    return jsonify(prediction=label, peak_probability=p)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
