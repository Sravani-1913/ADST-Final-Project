"""Train, persist and serve ML + Deep Learning models."""
import os
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from data_gen import DAYS, EXERCISES, generate

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(HERE, "data", "gym_data.csv")
POSTURE_PATH = os.path.join(HERE, "data", "posture_model.joblib")
PEAK_PATH = os.path.join(HERE, "data", "peak_model.joblib")
DEEP_PATH = os.path.join(HERE, "data", "deep_learning_posture_model.joblib")

POSTURE_FEATURES = ["knee_angle", "back_angle", "depth_ratio", "form_score"] + [f"ex_{e}" for e in EXERCISES]
PEAK_FEATURES = ["hour", "occupancy", "session_minutes"] + [f"day_{d}" for d in DAYS]


def _posture_X(df):
    X = df[["knee_angle", "back_angle", "depth_ratio", "form_score"]].copy()
    for e in EXERCISES:
        X[f"ex_{e}"] = (df["exercise"] == e).astype(int)
    return X[POSTURE_FEATURES]


def _peak_X(df):
    X = df[["hour", "occupancy", "session_minutes"]].copy()
    for d in DAYS:
        X[f"day_{d}"] = (df["day"] == d).astype(int)
    return X[PEAK_FEATURES]


def load_data():
    if not os.path.exists(DATA_PATH):
        os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
        generate().to_csv(DATA_PATH, index=False)
    return pd.read_csv(DATA_PATH)


def train(df=None):
    df = load_data() if df is None else df
    metrics = {}

    Xp, yp = _posture_X(df), df["posture"]
    Xtr, Xte, ytr, yte = train_test_split(Xp, yp, test_size=0.2, random_state=1, stratify=yp)
    posture = RandomForestClassifier(n_estimators=200, random_state=1).fit(Xtr, ytr)
    metrics["posture_accuracy"] = round(accuracy_score(yte, posture.predict(Xte)), 3)

    # Deep Learning: a feed-forward neural network with 3 hidden layers.
    deep = Pipeline([
        ("scaler", StandardScaler()),
        ("neural_network", MLPClassifier(
            hidden_layer_sizes=(64, 32, 16),
            activation="relu",
            solver="adam",
            max_iter=500,
            random_state=1,
            early_stopping=False,
        )),
    ])
    deep.fit(Xtr, ytr)
    metrics["deep_learning_accuracy"] = round(accuracy_score(yte, deep.predict(Xte)), 3)

    Xk, yk = _peak_X(df), df["is_peak"]
    Xtr, Xte, ytr, yte = train_test_split(Xk, yk, test_size=0.2, random_state=1, stratify=yk)
    peak = GradientBoostingClassifier(random_state=1).fit(Xtr, ytr)
    metrics["peak_accuracy"] = round(accuracy_score(yte, peak.predict(Xte)), 3)

    joblib.dump(posture, POSTURE_PATH)
    joblib.dump(deep, DEEP_PATH)
    joblib.dump(peak, PEAK_PATH)
    return metrics


def load_models():
    # Train all models if any saved model is missing.
    if not all(os.path.exists(p) for p in (POSTURE_PATH, DEEP_PATH, PEAK_PATH)):
        print("Training models:", train())
    return joblib.load(posture_path := POSTURE_PATH), joblib.load(deep_path := DEEP_PATH), joblib.load(peak_path := PEAK_PATH)


def predict_posture(model, exercise, knee, back, depth, score):
    row = pd.DataFrame([{
        "knee_angle": knee, "back_angle": back, "depth_ratio": depth,
        "form_score": score, "exercise": exercise,
    }])
    proba = model.predict_proba(_posture_X(row))[0]
    classes = list(model.classes_)
    best = int(np.argmax(proba))
    return classes[best], {c: round(float(p), 3) for c, p in zip(classes, proba)}


def predict_peak(model, day, hour, occupancy, session):
    row = pd.DataFrame([{"day": day, "hour": hour, "occupancy": occupancy, "session_minutes": session}])
    proba = model.predict_proba(_peak_X(row))[0]
    return ("PEAK" if proba[1] >= 0.5 else "OFF-PEAK"), round(float(proba[1]), 3)


def form_feedback(exercise, knee, back, depth):
    tips = []
    if back > 25:
        tips.append("Sit or stand tall and keep your back comfortable.")
    if depth < 0.45:
        tips.append("Move slowly through a comfortable range of motion.")
    if exercise in ("Arm Raises", "Shoulder Rolls") and back > 18:
        tips.append("Relax your shoulders and avoid leaning backward.")
    if exercise in ("Seated March", "Standing March") and knee < 70:
        tips.append("Lift each knee gently, one at a time.")
    if exercise == "Seated Knee Extension" and knee < 100:
        tips.append("Straighten one lower leg gently, without locking the knee.")
    if exercise == "Standing Side Steps":
        tips.append("Take small controlled steps and use a chair for support if needed.")
    if exercise == "Heel Raises":
        tips.append("Hold a stable chair and raise your heels slowly.")
    if exercise == "Seated Bicep Curl":
        tips.append("Keep elbows close to your body and use light weights or water bottles.")
    if exercise == "Seated Torso Twist":
        tips.append("Turn gently from side to side without forcing the stretch.")
    if exercise == "Wrist Circles":
        tips.append("Make small, gentle circles with your wrists.")
    return tips or ["Form looks good. Move slowly and stay comfortable."]


if __name__ == "__main__":
    load_data()
    print(train())
