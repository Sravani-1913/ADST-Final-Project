"""Synthetic dataset for the Hostel Gym / Fitness Station tracker.

Each row is one exercise set captured by the (simulated) camera pipeline:
pose features + equipment usage context.
"""
import numpy as np
import pandas as pd

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
EXERCISES = [
    "Seated March", "Arm Raises", "Shoulder Rolls", "Seated Knee Extension",
    "Standing Side Steps", "Heel Raises", "Seated Bicep Curl",
    "Seated Torso Twist", "Wrist Circles", "Standing March"
]
EQUIPMENT = {
    "Seated March": "Chair", "Arm Raises": "Open Space", "Shoulder Rolls": "None",
    "Seated Knee Extension": "Chair", "Standing Side Steps": "Open Space",
    "Heel Raises": "Chair Support", "Seated Bicep Curl": "Light Dumbbells or Water Bottles",
    "Seated Torso Twist": "Chair", "Wrist Circles": "None", "Standing March": "Chair Support"
}

LABELS = ["Dangerous", "Needs Improvement", "Good"]

# (knee_mean, back_mean, depth_mean) for a perfect rep of each exercise
IDEAL = {
    "Seated March": (100, 8, 0.75), "Arm Raises": (165, 8, 0.80),
    "Shoulder Rolls": (160, 8, 0.70), "Seated Knee Extension": (150, 8, 0.75),
    "Standing Side Steps": (160, 8, 0.80), "Heel Raises": (170, 6, 0.75),
    "Seated Bicep Curl": (100, 8, 0.75), "Seated Torso Twist": (110, 10, 0.70),
    "Wrist Circles": (160, 5, 0.65), "Standing March": (110, 8, 0.80),
}


def _hour_weights():
    w = np.full(24, 0.0)
    w[6:9] = [3, 4, 2]          # morning rush
    w[9:16] = 1                 # quiet daytime
    w[16:22] = [4, 6, 8, 9, 7, 4]  # evening peak
    w[22] = 1
    return w / w.sum()


def generate(n=1200, seed=42):
    rng = np.random.default_rng(seed)
    hours = rng.choice(24, size=n, p=_hour_weights())
    days = rng.integers(0, 7, size=n)
    exercise = rng.choice(
        EXERCISES, size=n,
        p=[0.12, 0.12, 0.10, 0.12, 0.10, 0.10, 0.10, 0.08, 0.08, 0.08]
    )

    # latent skill/fatigue: 0 = terrible form, 1 = perfect
    quality = np.clip(rng.beta(8, 1.3, size=n), 0, 1)

    knee, back, depth = [], [], []
    for ex, q in zip(exercise, quality):
        k0, b0, d0 = IDEAL[ex]
        bad = 1 - q
        knee.append(k0 + rng.normal(0, 4) + rng.choice([-1, 1]) * bad * 28)
        back.append(max(0, b0 + rng.normal(0, 3) + bad * 38))
        depth.append(np.clip(d0 + rng.normal(0, 0.04) - bad * 0.35, 0.2, 1.1))
    knee, back, depth = np.array(knee), np.array(back), np.array(depth)

    ideal_k = np.array([IDEAL[e][0] for e in exercise])
    ideal_b = np.array([IDEAL[e][1] for e in exercise])
    ideal_d = np.array([IDEAL[e][2] for e in exercise])
    penalty = (np.abs(knee - ideal_k) / 30 * 35
               + np.clip(back - ideal_b, 0, None) / 40 * 40
               + np.clip(ideal_d - depth, 0, None) / 0.4 * 25)
    form_score = np.clip(100 - penalty + rng.normal(0, 2, n), 20, 100).round(1)

    posture = np.where(form_score >= 80, "Good",
                       np.where(form_score >= 60, "Needs Improvement", "Dangerous"))
    # Coach labelling is imperfect: ~8% of sets land in an adjacent class.
    order = ["Dangerous", "Needs Improvement", "Good"]
    flip = rng.random(n) < 0.08
    shift = rng.choice([-1, 1], size=n)
    idx = np.clip(np.array([order.index(p) for p in posture]) + np.where(flip, shift, 0), 0, 2)
    posture = np.array([order[i] for i in idx])

    base_occ = _hour_weights()[hours] * 300
    weekend = np.isin(days, [5, 6])
    occupancy = np.clip(base_occ * np.where(weekend, 0.8, 1.0)
                        + rng.normal(0, 4, n), 1, 60).round().astype(int)
    session = np.clip(rng.normal(25, 8, n), 5, 60).round().astype(int)
    reps = np.clip((form_score / 100 * 14 + rng.normal(0, 2, n)).round(), 3, 20).astype(int)

    is_peak = ((occupancy >= 28) | ((hours >= 17) & (hours <= 20))).astype(int)
    noisy = rng.random(n) < 0.06  # operator misclassification / unusual days
    is_peak = np.where(noisy, 1 - is_peak, is_peak)

    return pd.DataFrame({
        "day": [DAYS[d] for d in days],
        "hour": hours,
        "exercise": exercise,
        "equipment": [EQUIPMENT[e] for e in exercise],
        "knee_angle": knee.round(1),
        "back_angle": back.round(1),
        "depth_ratio": depth.round(2),
        "form_score": form_score,
        "reps": reps,
        "posture": posture,
        "occupancy": occupancy,
        "session_minutes": session,
        "is_peak": is_peak,
    })


if __name__ == "__main__":
    import os
    out = os.path.join(os.path.dirname(__file__), "data", "gym_data.csv")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    df = generate()
    df.to_csv(out, index=False)
    print(f"Wrote {len(df)} rows to {out}")
