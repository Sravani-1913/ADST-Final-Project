# Hostel Gym / Fitness Station AI Tracker

Features:
- Login/logout (demo: sravani / sravani123)
- Clickable sidebar navigation
- Dataset and colourful dashboard analytics
- 10 easy seated/standing exercises: Seated March, Arm Raises, Shoulder Rolls, Seated Knee Extension, Standing Side Steps, Heel Raises, Seated Bicep Curl, Seated Torso Twist, Wrist Circles, Standing March
- Clickable sidebar with Dashboard, Workout Planner, Exercise Library, AI Posture, Webcam, Deep Learning, Equipment Usage, Progress Tracker and System Status
- Workout planner, searchable exercise library and browser-saved progress tracker
- Random Forest posture prediction
- Gradient Boosting equipment peak prediction
- Deep Learning posture prediction using a 3-hidden-layer MLP (64 -> 32 -> 16)

## Run
1. Open terminal in the project folder.
2. Install dependencies: `pip install -r requirements.txt`
3. Run: `python backend/app.py`
4. Open: `http://127.0.0.1:5000`

The deep-learning model is trained automatically the first time if its saved model file is missing.


## Live webcam
- Click **Live Webcam** in the sidebar.
- Click **Start Camera** and allow browser camera permission.
- MediaPipe Pose detects body landmarks in the browser.
- Knee angle, back angle, depth and form score are calculated from the live pose.
- Those features are sent to the trained 3-hidden-layer Deep Learning model (64 -> 32 -> 16).
- The page shows posture, confidence, repetition count and corrective feedback.
- Click **Stop Camera** before leaving the page.

Note: the first webcam load uses the MediaPipe Pose JavaScript library from jsDelivr, so internet access is required for pose detection. Camera access normally works on localhost (`http://127.0.0.1:5000`).


## Easy exercise dataset
The sample dataset uses gentle seated and standing movements. No push-ups, lunges, or squats are included. Standing exercises can be done while holding a stable chair for support. The dataset is synthetic/demo data, not real sensor measurements.
